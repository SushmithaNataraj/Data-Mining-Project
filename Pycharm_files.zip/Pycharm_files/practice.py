s = "abc2"
for ch in s:
    if ch.isalpha():
        print(ch*2)
print(s.isalpha())
print(ord('0'))
print(s[-2])
lst = [1,2,3,4,5,5,8,9,1,2,3,4,0,100,1000,7,8,78]

lst = []
while 1:
    lst.append(0)


print(lst)