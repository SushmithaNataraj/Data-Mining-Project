from google.cloud import bigquery
import matplotlib.pyplot as plt
from google.oauth2 import service_account
credentials = service_account.Credentials.from_service_account_file(
    "/Users/sushmitha/PycharmProjects/dmproject/authentication_key.json",
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)
client = bigquery.Client(
    credentials=credentials,
    project=credentials.project_id,
)
taxi_trip_dataset_ref = client.dataset('chicago_taxi_trips', project='bigquery-public-data')
taxi_trip_dataset_ref = bigquery.dataset.DatasetReference('bigquery-public-data', 'chicago_taxi_trips')
taxi_trip_dset = client.get_dataset(taxi_trip_dataset_ref)
taxi_trips_table = client.get_table(taxi_trip_dset.table('taxi_trips'))

def trip_duration():
    return


query_string = """
                    
               """
