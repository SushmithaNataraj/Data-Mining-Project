from google.cloud import bigquery
import matplotlib.pyplot as plt
from google.oauth2 import service_account
import numpy as np
import pandas as pd
import scipy
import math
from sklearn.cluster import AgglomerativeClustering
from sklearn.cluster import KMeans
import csv


'''
SELECT trip_seconds, fare
From `bigquery-public-data.chicago_taxi_trips.taxi_trips` WHERE EXTRACT(YEAR FROM trip_start_timestamp ) = 2019 and EXTRACT(MONTH FROM trip_start_timestamp ) = 1 and trip_seconds >0 and trip_miles != 0
ORDER BY trip_seconds
'''
credentials = service_account.Credentials.from_service_account_file(
    "/Users/sushmitha/PycharmProjects/dmproject/authentication_key.json",
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)
client = bigquery.Client(
    credentials=credentials,
    project=credentials.project_id,
)

taxi_trip_dataset_ref = client.dataset('chicago_taxi_trips', project='bigquery-public-data')
taxi_trip_dataset_ref = bigquery.dataset.DatasetReference('bigquery-public-data', 'chicago_taxi_trips')

taxi_trip_dset = client.get_dataset(taxi_trip_dataset_ref)

taxi_trips_table = client.get_table(taxi_trip_dset.table('taxi_trips'))


def duration_fare():
    data = open("fareVsDuration.csv")
    readCSV = csv.reader(data)
    #preview first 5 fields
    trip_seconds = []
    trip_fare = []
    for row in readCSV:
        # print(row)
        #print(row[0],row[1])
        trip_seconds.append(row[0])
        trip_fare.append(row[1])

    trip_seconds.pop(0)
    trip_fare.pop(0)

    plt.xlabel("Trip Duration (S)")
    plt.ylabel("Trip Fare")

    plt.scatter(trip_seconds, trip_fare, color="green")
    plt.suptitle("Plot that shows how Trip Fare varies according Trip duration")
    plt.show()

duration_fare()