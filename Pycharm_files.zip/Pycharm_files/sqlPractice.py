from google.cloud import bigquery
import pandas as pd

client = bigquery.Client()
ds_ref = client.dataset('chicago_taxi_trips', project='bigquery-public-data')
ds = client.get_dataset(ds_ref)
for d in client.list_tables(ds):
    print(d.table_id)
tbl = client.get_table(ds.table('taxi_trips'))
print(tbl.schema)


