import pandas as pd
import numpy as np
import csv
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import sys
from mpl_toolkits.basemap import Basemap

def location_vs_fare():
    data = open("fareVsLatlong.csv")
    readCSV = csv.reader(data)
    lat = []
    lng = []
    avg_fare = []
    f = 0
    for row in readCSV:
        if f == 0:
            f = 1
            continue
        print(row)
        lat.append(float(row[0]))
        lng.append(float(row[1]))
        avg_fare.append(float(row[2]))
    print(lat)
    print(lng)
    print(avg_fare)

location_vs_fare()